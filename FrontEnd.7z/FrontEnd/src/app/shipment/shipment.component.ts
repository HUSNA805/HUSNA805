import { Component, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs';
import { IRequestResult, IShipmentList, IShipmentRequest, ShipmentType } from '../shipment.model';
import { AlertService } from '../_helpers/alert.service';
import { ShipmentService } from '../shipment.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-shipment',
  templateUrl: './shipment.component.html',
  styleUrls: ['./shipment.component.css']
})
export class ShipmentComponent implements OnInit {

  constructor(private alert: AlertService, private spinner: NgxSpinnerService, private service: ShipmentService) { }

  dtOptions: DataTables.Settings = {};

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtTrigger: Subject<any> = new Subject();

  ShipmentType: any = ShipmentType;
  shipmentDeatils: IShipmentRequest =
  {
    shipmentId: 0,
    senderName: "",
    description: "",
    recipientAddress: "",
    expedited: false,
    shipmentType: 0
  }
  requestResult: IRequestResult;
  SHipmentList: IShipmentRequest[] = [];

  canEdit: boolean = false;
  canUpdate: boolean = false;
  canSubmit: boolean = true;
  ModalClicked: boolean = false;
  spin: number;

  ngOnInit(): void {
    this.GetShipmentList();
    this.spin = setTimeout(() => {
      this.spinner.show();
    }, 1000);

    this.dtOptions = {
      pagingType: 'full_numbers',
      retrieve: true,
    };
  }

  getKeys(obj: any) { return Object.keys(obj).filter(x => isNaN(obj[x])); }

  GetShipmentList()
  {
    this.service.GetShipmentList().subscribe((res) => {
      this.SHipmentList = res.shipment;
      clearTimeout(this.spin);
      setTimeout(() => {
        /** spinner ends after 2 ms */
        this.spinner.hide();
      }, 250);
      this.dtTrigger.next();
      },
      (err) => {
        clearTimeout(this.spin);
        this.spinner.hide();
        this.alert.error(err.message);
    });
  }

  onButtonClicked()
  {
    this.ModalClicked = true;
    this.shipmentDeatils.senderName = "",
    this.shipmentDeatils.description = "",
    this.shipmentDeatils.recipientAddress = "";
    this.shipmentDeatils.shipmentType = null;
    this.shipmentDeatils.expedited = false;
    this.GetShipmentList();
  }

  onSubmit(shipmentFrm: NgForm)
  {
    this.shipmentDeatils.shipmentType = parseInt(shipmentFrm.controls['shipmentType'].value);
    this.service.PostShipment(this.shipmentDeatils).subscribe(
      (res) => {
        this.requestResult = res;
        clearTimeout(this.spin);
        setTimeout(() => {
          this.spinner.hide();
        }, 500);
        this.alert.success(res.message);
        this.resetForm(shipmentFrm, false);
      },
      (err) => {
        clearTimeout(this.spin);
        setTimeout(() => {
          this.spinner.hide();
        }, 500);
        this.alert.error(err.message);
      }
    );
    window.scrollTo(0,0);
  }

  resetForm(form: NgForm, Istrue:boolean)
  {
    this.canEdit = Istrue;
    this.canUpdate = Istrue;
    this.canSubmit = !Istrue; 

    this.shipmentDeatils.senderName = "",
    this.shipmentDeatils.description = "",
    this.shipmentDeatils.recipientAddress = "",
    this.shipmentDeatils.shipmentType = null,
    this.shipmentDeatils.expedited = false,
    
    form.resetForm();
    this.GetShipmentList();
  }

  onedit(form: IShipmentRequest, Istrue:boolean) {
    this.shipmentDeatils = form;
    this.canEdit = Istrue;
    this.canUpdate = Istrue;
    this.canSubmit = !Istrue;
    this.ModalClicked = true;
    window.scrollTo(0,0);
  }

  onUpdate(shipmentFrm: NgForm)
  {
    this.shipmentDeatils.shipmentType = parseInt(shipmentFrm.controls['shipmentType'].value);
    this.service.UpdateShipment(this.shipmentDeatils).subscribe(
      (res) => {
        this.requestResult = res;
        clearTimeout(this.spin);
        setTimeout(() => {
          this.spinner.hide();
        }, 500);
        this.alert.success(res.message);
        this.resetForm(shipmentFrm, false);
      },
      (err) => {
        clearTimeout(this.spin);
        setTimeout(() => {
          this.spinner.hide();
        }, 500);
        this.alert.error(err.message);
      }
    );
    window.scrollTo(0,0);
  }

  onClickDelete(shipmentId: number)
  {
    this.shipmentDeatils.shipmentId = shipmentId;
  }

  onDelete()
  {
    this.service.DeleteShipment(this.shipmentDeatils.shipmentId).subscribe(
      (res) => {
        this.requestResult = res;
        clearTimeout(this.spin);
        setTimeout(() => {
          this.spinner.hide();
        }, 500);
        this.alert.success(res.message);
        this.onButtonClicked();
        this.ModalClicked = false;
        this.GetShipmentList();
      },
      (err) => {
        clearTimeout(this.spin);
        setTimeout(() => {
          this.spinner.hide();
        }, 500);
        this.alert.error(err.message);
      }
    );
    window.scrollTo(0,0);
  }

  onModalClose()
  {
    this.ModalClicked = false;
    this.canSubmit = true;
    this.canUpdate = false;
    this.canEdit = false;
  }
}
