import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IRequestResult, IShipmentList } from './shipment.model';

@Injectable({
  providedIn: 'root'
})
export class ShipmentService {

  constructor(private http: HttpClient) { }

  GetShipmentList(): Observable<IShipmentList> {
    return this.http.get<IShipmentList>(
      environment.apiBaseUrl + '/Shipment/ShipmentList'
    );
  }

  PostShipment<IShipmentRequest>(shipmentDeatils: IShipmentRequest): Observable<IRequestResult> {
    return this.http.post<IRequestResult>(
      environment.apiBaseUrl + '/Shipment/AddShipmentDetails',
      shipmentDeatils,
    )
  }

  UpdateShipment<IShipmentRequest>(shipmentDeatils: IShipmentRequest): Observable<IRequestResult> {
    return this.http.post<IRequestResult>(
      environment.apiBaseUrl + '/Shipment/UpdateShipmentDetails',
      shipmentDeatils,
    )
  }

  DeleteShipment(shipmentId: number): Observable<IRequestResult> {
    if (shipmentId === null || shipmentId === 0) {
      alert('Select a Item Code to delete');
      return;
    }
    return this.http.get<IRequestResult>(
      environment.apiBaseUrl +
        '/Shipment/DeleteShipmentDetail/?ShipmentId=' + shipmentId,
    );
  }

}
