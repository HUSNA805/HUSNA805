export interface IShipmentRequest
{
    shipmentId: number;
    senderName: string;
    description: string;
    recipientAddress: string;
    expedited: boolean;
    shipmentType: ShipmentType;
}

export interface IShipmentList
{
    status: boolean;
    message: string;
    shipment: IShipmentRequest[];
}

export interface IRequestResult
{
    message: string;
    status: boolean;
    responseCode: string;
}

export enum ShipmentType
{
    LTL = 1,
    Volume_LTL = 2,
    TruckLoad = 3
}